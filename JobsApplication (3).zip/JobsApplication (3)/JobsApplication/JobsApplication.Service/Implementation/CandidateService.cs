﻿using JobsApplication.Domain.DomainModels;
using JobsApplication.Repository.Interface;
using JobsApplication.Service.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JobsApplication.Service.Implementation
{
    public class CandidateService : ICandidateService
    {
        private readonly IRepository<Candidate> _candidateRepository;

        public CandidateService(IRepository<Candidate> candidateRepository)
        {
            _candidateRepository = candidateRepository;
        }

        public Candidate DeleteById(Guid id)
        {
            var product = _candidateRepository.Get(selector: x => x,
                                                predicate: x => x.Id == id);
            return _candidateRepository.Delete(product);
        }

        public List<Candidate> GetAll()
        {
            return _candidateRepository.GetAll(selector: x => x).ToList();
        }

        public Candidate? GetById(Guid id)
        {
            return _candidateRepository.Get(selector: x => x,
                                            predicate: x => x.Id == id);
        }

        public Candidate Insert(Candidate candidate)
        {
            return _candidateRepository.Insert(candidate);
        }

        public Candidate Update(Candidate candidate)
        {
            return _candidateRepository.Update(candidate);
        }
    }
}
