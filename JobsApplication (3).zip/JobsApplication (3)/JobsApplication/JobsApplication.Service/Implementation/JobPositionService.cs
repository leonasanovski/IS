﻿using JobsApplication.Domain.DomainModels;
using JobsApplication.Repository.Interface;
using JobsApplication.Service.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JobsApplication.Service.Implementation
{
    public class JobPositionService : IJobPositionService
    {
        private readonly IRepository<JobPosition> _jobPositionRepository;

        public JobPositionService(IRepository<JobPosition> jobPositionRepository)
        {
            _jobPositionRepository = jobPositionRepository;
        }

        public JobPosition DeleteById(Guid id)
        {
            var product = _jobPositionRepository.Get(selector: x => x,
                                    predicate: x => x.Id == id);
            return _jobPositionRepository.Delete(product);
        }

        public List<JobPosition> GetAll()
        {
            return _jobPositionRepository.GetAll(selector: x => x).ToList();

        }

        public JobPosition? GetById(Guid id)
        {
            return _jobPositionRepository.Get(selector: x => x,
                                            predicate: x => x.Id == id);
        }

        public JobPosition Insert(JobPosition jobPosition)
        {
            return _jobPositionRepository.Insert(jobPosition);
        }

        public JobPosition Update(JobPosition jobPosition)
        {
            return _jobPositionRepository.Update(jobPosition);

        }
    }
}
