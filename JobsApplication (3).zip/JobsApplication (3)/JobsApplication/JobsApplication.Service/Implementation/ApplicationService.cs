﻿using JobsApplication.Domain.DomainModels;
using JobsApplication.Repository.Interface;
using JobsApplication.Service.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JobsApplication.Service.Implementation
{
    public class ApplicationService : IApplicationService
    {
        private readonly IRepository<Application> _applicationRepository;
        private readonly IRepository<Candidate> _candidateRepository;
        private readonly IRepository<JobPosition> _jobPositionRepository;

        public ApplicationService(IRepository<Application> applicationRepository, IRepository<Candidate> candidateRepository, IRepository<JobPosition> jobPositionRepository)
        {
            _applicationRepository = applicationRepository;
            _candidateRepository = candidateRepository;
            _jobPositionRepository = jobPositionRepository;
        }

        public Application ScheduleApplicationForCandidateAndPosition(Guid candidateId, Guid positionId, string userId)
        {
            var candidate = _candidateRepository.Get(selector: x => x, predicate: x => x.Id == candidateId);
            var job_position = _jobPositionRepository.Get(selector: x => x, predicate: x => x.Id == positionId);


            Application new_obj = new Application
            {
                Id = Guid.NewGuid(),
                Candidate = candidate,
                CandidateId = candidateId,
                JobPosition = job_position,
                JobPositionId = positionId,
                AppliedDate = DateTime.Now,
                userId = userId,
                Status = "status"
            };
            _applicationRepository.Insert(new_obj);
            return new_obj;
        }
    }
}
