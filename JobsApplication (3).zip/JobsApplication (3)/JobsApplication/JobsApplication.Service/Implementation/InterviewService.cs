﻿using JobsApplication.Domain.DomainModels;
using JobsApplication.Repository.Interface;
using JobsApplication.Service.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JobsApplication.Service.Implementation
{
    public class InterviewService : IInterviewService
    {
        private readonly IRepository<Interview> _interviewService;

        public InterviewService(IRepository<Interview> interviewService)
        {
            _interviewService = interviewService;
        }

        public Interview DeleteById(Guid id)
        {
            var product = _interviewService.Get(selector: x => x,
                                                predicate: x => x.Id == id);
            return _interviewService.Delete(product);
        }

        public List<Interview> GetAll()
        {
            return _interviewService.GetAll(selector: x => x).ToList();

        }

        public Interview? GetById(Guid id)
        {
            return _interviewService.Get(selector: x => x,
                                            predicate: x => x.Id == id);
        }

        public Interview Insert(Interview interview)
        {
            return _interviewService.Insert(interview);

        }

        public Interview Update(Interview interview)
        {
            return _interviewService.Update(interview);

        }
    }
}
