﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Intership.Domain.DomainModels
{
    public class Candidate
    {
        //Candidate (FirstName, LastName, DateOfBirth, Email, PhoneNumber)
        //Сите атрибути освен PhoneNumber се задолжителни
        [Key]
        public Guid Id { get; set; }
        [Required]
        public string? FirstName { get; set; }
        [Required]
        public string? LastName { get; set; }
        [Required]
        public DateTime? DateOfBirth { get; set; }
        [Required]
        public string? Email { get; set; }
        public string? PhoneNumber { get; set; }
        public virtual ICollection<Application>? Applications { get; set; }
    }
}
