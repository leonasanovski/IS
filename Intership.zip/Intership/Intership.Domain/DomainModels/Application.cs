﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Intership.Domain.DomainModels
{
    public class Application
    {
        [Key]
        public Guid Id { get; set; }
        public DateTime AppliedDate { get; set; }
        public string? Status { get; set; }
        public Candidate? CandidateThatApplied { get; set; }
        public JobPosition? JobPositionAppliance { get; set; }
    }
}
