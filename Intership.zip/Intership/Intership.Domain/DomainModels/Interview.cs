﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Intership.Domain.DomainModels
{
    public class Interview
    {
        [Key]
        public Guid Id { get; set; }
        public DateTime InterviewDate { get; set; }
        public string? InterviewType { get; set; }
        public string? Notes { get; set; }
        public JobPosition? JobPosition { get; set; }
    }
}
