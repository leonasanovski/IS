﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Intership.Domain.DomainModels
{
    public class JobPosition
    {
        [Key]
        public Guid Id { get; set; }
        public string? Title { get; set; }
        public string? Department { get; set; }
        public string? Location { get; set; }
        public virtual ICollection<Application>? ApplicationsForJobPosition { get; set; }
        public virtual ICollection<Interview>? InterviewsForJobPosition { get; set; }
    }
}
