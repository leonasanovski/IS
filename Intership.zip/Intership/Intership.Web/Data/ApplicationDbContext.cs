﻿using Intership.Domain.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Intership.Domain.DomainModels;

namespace Intership.Web.Data
{
    public class ApplicationDbContext : IdentityDbContext<JobsApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public virtual DbSet<Application> Applications { get; set; }
        public virtual DbSet<Candidate> Candidates { get; set; }
        public virtual DbSet<Interview> Interviews { get; set; }
        public virtual DbSet<JobPosition> JobPositions { get; set; }

    }
}
